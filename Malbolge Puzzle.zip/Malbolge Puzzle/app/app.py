import socket
import subprocess               
import threading



def Malbolge(Connection):
    Connection.send(b"Welcome to the eighth circle of esoteric hell!\nMake this interpreter return \"Hello, world.\" to get the flag...\n")
    while True:
        data = Connection.recv(1024)
        if not data:
            break
        try:
            f = open("Input.md", "w")
            f.write(data.decode("utf-8").strip("\n"))
            f.close()
            Output = subprocess.run(['/app/Malbolge', "Input.md"], stdout=subprocess.PIPE, timeout=2)
        except Exception as e:
            Decoded = ""
            print(e)
        Decoded = (Output.stdout).decode("utf-8")
        if Decoded == "Hello, world.":
            Connection.send(b"Output: " +Output.stdout+b"\n")
            Connection.send(b"FLAG{gander}\n")
            break
        else:
            Connection.send(b"Output: " + Output.stdout+b"\n")
            Connection.send(b"Incorrect code, try again...\n")
    Connection.close()  


if __name__ == "__main__":
    MalbolgeSocket = socket.socket()         
    host = socket.gethostname() 
    port = 4444                
    MalbolgeSocket.bind((host, port))        
    MalbolgeSocket.listen(5)                 
    while True:
        Connection, addr = MalbolgeSocket.accept()
        MalbolgeThread = threading.Thread(target=Malbolge, args=(Connection,))
        MalbolgeThread.start()