#!/bin/bash
service ssh start
apachectl start 
tail -f /dev/null