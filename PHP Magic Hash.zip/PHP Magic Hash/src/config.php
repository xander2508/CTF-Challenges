<?php

/* Define username and password */
$Username = 'Admin';
$Password = '0e462097431906509019562988736854';
